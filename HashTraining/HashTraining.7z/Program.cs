﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace HashTraining
{
	class Program
	{
		static void Main(string[] args)
		{
			DataManager DataManager = new DataManager();
			var model = DataManager.ReadFromFile("e_also_big.in");
			ClasicSolutionD clasicSolutionD = new ClasicSolutionD(model);
			var outputModel = clasicSolutionD.CreateOuputModel("e_also_big");
			DataManager.WriteToFile("e_also_big", outputModel);
			Console.Read();
		}
	}
}
